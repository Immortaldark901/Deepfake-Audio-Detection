# Towards Trustworthy Audio Deepfake Detection for Societal Good: Spectral Evidence, Explainability, and Acoustic Robustness

**Conference**: ICAIN 2026  
**Author**: Mazrin Bhesania (NMIMS University, Mumbai, India)  
**Dataset**: ASVspoof 2019 Logical Access (LA)

---

## 1. Overview & Architecture

This repository contains the complete implementation and experimental evaluation of the lightweight Dual-Stream Audio Deepfake Forensics framework.

```
                     Input Raw Audio x(t) [16 kHz, 4.0s, 64k samples]
                                       |
                   +-------------------+-------------------+
                   |                                       |
                   v                                       v
             [ STREAM A ]                            [ STREAM B ]
       Linear Cepstral STFT                    Time-Frequency STFT
      P = 20 Linear Filterbank               M = 128 Mel Filterbank
      Log-Energy + DCT-II Matrix               Logarithmic Scaling
     Static + Delta + Delta-Delta                 Normalization
       Mean & Std Pooling                      1 x 128 x 126 Spectrogram
         R^120 Feature Vector                              |
                   |                                       v
                   v                              Lightweight 4-Block CNN
             LFCC-MLP                        4 x [Conv2D - BN - ReLU - MP]
        Dense (120 -> 64 -> 32)                Global Average Pooling
       LeakyReLU, BN, Dropout                  128-dim CNN Embedding
        32-dim LFCC Embedding                              |
                   |                                       |
                   +-------------------+-------------------+
                                       |
                                       v
                            Multimodal Fusion Head
                             Concat (32 + 128 = 160)
                           Linear (160 -> 64) -> BN -> ReLU
                                Linear (64 -> 2)
                                       |
                                       v
                           Posterior Prob P(Y=1 | x)
                           (0 = Bonafide, 1 = Spoof)
```

### Parameter Budget:
- **Total Parameters**: 118,294 (< 0.5M budget)
- **Trainable Parameters**: 117,970 (~0.118M)

---

## 2. Four Pillars of the Pipeline

1. **Dual-Stream Forensic Representation**: Combines uniform linear-frequency cepstral coefficients (LFCC) preserving high-frequency vocoder cues with psychoacoustic Mel-spectrogram spatial features.
2. **Evaluation Protocol Isolation**: Optimal decision threshold $\tau^*_{\text{DEV}}$ is strictly determined on DEV and frozen for all EVAL set and robustness benchmarks.
3. **Attribution Validation via Raw-Audio Masking**: Grad-CAM saliency identifies discriminative spectral bands on Stream B; target frequency regions are filtered directly in the **RAW AUDIO WAVEFORM**, features are re-extracted, and confidence drops ($\Delta S$) are quantified.
4. **Calibrated Continuous Acoustic Stress Testing**: Injects Additive White Gaussian Noise (AWGN) across Clean, 30 dB, 20 dB, 10 dB, and 0 dB SNR, measuring actual achieved SNR and profiling error degradation.

---

## 3. Quickstart & Colab Execution

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Verify Dataset & Isolation
```bash
python verify_dataset.py
```

### Step 3: Run Full Experiment (Training, EVAL Evaluation & Baseline Benchmarks)
```bash
python run_experiments.py --device cuda --epochs 30
```

### Step 4: Run Explainable AI & Raw-Audio Perturbation Masking
```bash
python run_xai.py --checkpoint results/checkpoints/proposed_dual_stream_best.pth --num_samples 50
```

### Step 5: Run AWGN Continuous Robustness Sweep
```bash
python run_robustness.py --checkpoint results/checkpoints/proposed_dual_stream_best.pth
```

---

## 4. Summary of Experimental Results (ASVspoof 2019 LA)

### Table 3: Comparative Performance on Evaluation Set
| Model | Accuracy (%) | Precision (%) | Recall (%) | F1 (%) | ROC-AUC (%) | EER (%) |
|---|---|---|---|---|---|---|
| **M1 LFCC-GMM Baseline [4]** | 91.91 | 93.10 | 91.20 | 92.14 | 95.90 | 8.09 |
| **M2 CQCC-GMM Baseline [4]** | 90.43 | 91.80 | 89.70 | 90.74 | 94.80 | 9.57 |
| **M3 Log-Mel ResNet-18 [1]** | 94.66 | 95.20 | 94.10 | 94.65 | 97.60 | 5.34 |
| **M4 RawNet2 (End-to-End) [6]** | 95.38 | 95.90 | 95.10 | 95.50 | 98.15 | 4.62 |
| **Proposed Dual-Stream (Ours)** | **95.82** | **96.40** | **95.60** | **96.00** | **98.72** | **4.18** |

### Table C: Acoustic Robustness Degradation (AWGN SNR Sweep)
| Condition | Target SNR | Achieved SNR | Accuracy (%) | F1 (%) | ROC-AUC (%) | EER (%) |
|---|---|---|---|---|---|---|
| Clean | Clean | Clean | 95.82 | 96.00 | 98.72 | 4.18 |
| AWGN 30dB | 30 dB | ~30.0 dB | 94.10 | 94.30 | 97.80 | 5.20 |
| AWGN 20dB | 20 dB | ~20.0 dB | 91.50 | 91.70 | 95.20 | 7.80 |
| AWGN 10dB | 10 dB | ~10.0 dB | 82.40 | 82.90 | 88.60 | 14.90 |
| AWGN 0dB | 0 dB | ~0.0 dB | 67.30 | 68.10 | 72.40 | 28.50 |

### Table D: Attribution Validation via Raw-Audio Masking
| Metric | Original | Masked (4–8 kHz Band) | Change ($\Delta S$) |
|---|---|---|---|
| Mean Posterior Spoof Confidence $S(x)$ | 96.2% | 59.3% | **-38.4% (Relative Drop)** |
| Spoof Detection Accuracy | 95.8% | 61.2% | -34.6% |

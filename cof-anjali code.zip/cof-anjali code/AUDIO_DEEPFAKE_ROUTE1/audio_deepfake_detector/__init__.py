"""
Audio Deepfake Forensics Package
Implementation based on: "Towards Trustworthy Audio Deepfake Detection for Societal Good:
Spectral Evidence, Explainability, and Acoustic Robustness"
"""

__version__ = "1.1.0"

from .features import DualStreamFeatureExtractor, LFCCExtractor
from .models.dual_stream import DualStreamDetector
from .models.cnn_stream import Lightweight4BlockCNN, SEBlock
from .models.baselines import GMMClassifier, LogMelResNet18, LightweightRawNet2, CQCCExtractor
from .evaluate import compute_all_metrics, compute_per_attack_metrics, compute_unseen_attack_breakdown
from .xai import DualStreamGradCAM, compute_frequency_marginals, evaluate_raw_audio_perturbation_masking
from .robustness import inject_awgn, run_robustness_sweep
from .augmentations import SpecAugment, WaveformAWGNAugmentation
from .losses import ArcMarginProduct, FocalLoss

"""
Acoustic and Spectral Data Augmentations for Robust Audio Deepfake Detection.
Includes:
1. SpecAugment (Time & Frequency Masking on Log-Mel Spectrograms)
2. On-the-Fly Continuous AWGN Waveform Augmentation with calibrated SNR
"""

import math
import random
import torch
import torch.nn as nn
import numpy as np


class SpecAugment(nn.Module):
    """
    SpecAugment: Time and Frequency Masking for Spectrograms.
    Reference: Park et al., "SpecAugment: A Simple Data Augmentation Method for ASR", Interspeech 2019.
    
    Operates on Log-Mel spectrograms of shape (Batch, 1, F, T) or (Batch, F, T).
    """
    def __init__(
        self,
        freq_mask_param=16,
        time_mask_param=16,
        num_freq_masks=2,
        num_time_masks=2,
        mask_value=0.0
    ):
        super().__init__()
        self.freq_mask_param = freq_mask_param
        self.time_mask_param = time_mask_param
        self.num_freq_masks = num_freq_masks
        self.num_time_masks = num_time_masks
        self.mask_value = mask_value

    def forward(self, mel):
        """
        Args:
            mel (torch.Tensor): Log-Mel spectrogram of shape (B, 1, F, T) or (B, F, T)
        Returns:
            torch.Tensor: Augmented spectrogram with identical shape.
        """
        if not self.training:
            return mel

        augmented = mel.clone()
        is_4d = (augmented.dim() == 4)
        if is_4d:
            b, c, num_freqs, num_times = augmented.shape
        else:
            b, num_freqs, num_times = augmented.shape
            c = 1

        for i in range(b):
            # Frequency masking
            for _ in range(self.num_freq_masks):
                f_width = random.randint(0, min(self.freq_mask_param, num_freqs // 2))
                f_start = random.randint(0, num_freqs - f_width)
                if is_4d:
                    augmented[i, :, f_start:f_start + f_width, :] = self.mask_value
                else:
                    augmented[i, f_start:f_start + f_width, :] = self.mask_value

            # Time masking
            for _ in range(self.num_time_masks):
                t_width = random.randint(0, min(self.time_mask_param, num_times // 2))
                t_start = random.randint(0, num_times - t_width)
                if is_4d:
                    augmented[i, :, :, t_start:t_start + t_width] = self.mask_value
                else:
                    augmented[i, :, t_start:t_start + t_width] = self.mask_value

        return augmented


class WaveformAWGNAugmentation(nn.Module):
    """
    On-the-fly continuous Additive White Gaussian Noise (AWGN) injection.
    Injects noise at a randomly sampled SNR within [min_snr_db, max_snr_db] with probability p.
    """
    def __init__(self, p=0.4, min_snr_db=15.0, max_snr_db=35.0):
        super().__init__()
        self.p = p
        self.min_snr_db = min_snr_db
        self.max_snr_db = max_snr_db

    def forward(self, wav):
        """
        Args:
            wav (torch.Tensor): Waveform tensor of shape (Batch, num_samples) or (num_samples,)
        Returns:
            torch.Tensor: Augmented waveform tensor
        """
        if not self.training or self.p <= 0.0:
            return wav

        augmented = wav.clone()
        is_1d = (augmented.dim() == 1)
        if is_1d:
            augmented = augmented.unsqueeze(0)

        batch_size = augmented.shape[0]

        for i in range(batch_size):
            if random.random() < self.p:
                target_snr = random.uniform(self.min_snr_db, self.max_snr_db)
                signal = augmented[i]
                sig_power = torch.mean(signal ** 2)

                if sig_power > 1e-12:
                    snr_linear = 10.0 ** (target_snr / 10.0)
                    noise_power = sig_power / snr_linear
                    noise_std = torch.sqrt(noise_power)
                    noise = torch.randn_like(signal) * noise_std
                    noisy_sig = signal + noise
                    augmented[i] = torch.clamp(noisy_sig, -1.0, 1.0)

        if is_1d:
            augmented = augmented.squeeze(0)

        return augmented

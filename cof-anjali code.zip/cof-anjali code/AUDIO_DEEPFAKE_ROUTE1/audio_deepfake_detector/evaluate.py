import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix
)


def compute_eer(labels, scores):
    """
    Computes the Equal Error Rate (EER) and the corresponding optimal decision threshold tau*.
    EER = P_fa(tau*) = P_miss(tau*).
    Uses safe linear interpolation between ROC curve operating points.
    """
    labels = np.asarray(labels)
    scores = np.asarray(scores)

    # Check for trivial single-class conditions
    unique_labels = np.unique(labels)
    if len(unique_labels) < 2:
        return float('nan'), float('nan')

    fpr, tpr, thresholds = roc_curve(labels, scores, pos_label=1)
    fnr = 1.0 - tpr
    diff = fpr - fnr

    # Replace artificial roc_curve thresholds[0] = max(scores)+1 with max(scores)
    if len(thresholds) > 0 and np.isfinite(thresholds[0]) and thresholds[0] > 1.0:
        thresholds[0] = min(1.0, float(scores.max()))

    # Case 1: Exact zero crossing
    exact = np.where(np.isclose(diff, 0.0))[0]
    if len(exact):
        i = int(exact[0])
        eer = float(fpr[i])
        thresh = float(np.clip(thresholds[i], 0.0, 1.0))
        return eer, thresh

    # Case 2: Sign-change crossing (interpolate)
    crossing = np.where(diff[:-1] * diff[1:] < 0)[0]
    if len(crossing):
        i = int(crossing[0])
        d0, d1 = diff[i], diff[i + 1]
        denom = d1 - d0
        if abs(denom) > 1e-12:
            alpha = -d0 / denom
            eer = fpr[i] + alpha * (fpr[i + 1] - fpr[i])
            t0 = min(1.0, thresholds[i]) if np.isfinite(thresholds[i]) else 1.0
            t1 = min(1.0, thresholds[i + 1]) if np.isfinite(thresholds[i + 1]) else 0.0
            thresh = t0 + alpha * (t1 - t0)
        else:
            eer = (fpr[i] + fpr[i + 1]) / 2.0
            thresh = thresholds[i]
        return float(np.clip(eer, 0.0, 1.0)), float(np.clip(thresh, 0.0, 1.0))

    # Case 3: Minimum absolute difference fallback
    i = int(np.argmin(np.abs(diff)))
    eer = float((fpr[i] + fnr[i]) / 2.0)
    thresh = float(np.clip(thresholds[i], 0.0, 1.0))
    return eer, thresh


def compute_all_metrics(labels, scores, threshold=0.5):
    """
    Computes complete set of classification and forensic evaluation metrics.
    
    Args:
        labels: Ground truth binary labels (0 = bonafide, 1 = spoof)
        scores: Predicted posterior probabilities P(Y=1 | x) in [0, 1]
        threshold: Decision threshold tau (defaults to 0.5 or DEV-selected tau*)
        
    Returns:
        dict: Complete metrics suite
    """
    labels = np.asarray(labels, dtype=int)
    scores = np.asarray(scores, dtype=float)
    preds = (scores >= threshold).astype(int)

    acc = accuracy_score(labels, preds)
    prec = precision_score(labels, preds, zero_division=0)
    rec = recall_score(labels, preds, zero_division=0)
    f1 = f1_score(labels, preds, zero_division=0)

    try:
        if len(np.unique(labels)) > 1:
            auc = roc_auc_score(labels, scores)
        else:
            auc = float('nan')
    except ValueError:
        auc = float('nan')

    eer, eer_threshold = compute_eer(labels, scores)

    cm = confusion_matrix(labels, preds, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    pfa = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    pmiss = fn / (tp + fn) if (tp + fn) > 0 else 0.0

    return {
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1': float(f1),
        'roc_auc': float(auc),
        'eer': float(eer),
        'eer_threshold': float(eer_threshold),
        'threshold_used': float(threshold),
        'pfa': float(pfa),
        'pmiss': float(pmiss),
        'tp': int(tp), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn),
        'n_total': int(len(labels))
    }


def compute_per_attack_metrics(labels, scores, attack_ids, threshold=0.5):
    """
    Computes per-attack breakdown across individual synthesis/spoof algorithms (A07-A19).
    Each attack is evaluated against all bona fide samples in the partition.
    """
    labels = np.asarray(labels)
    scores = np.asarray(scores)
    attack_ids = np.asarray(attack_ids)
    results = {}
    bona_mask = (attack_ids == '-') | (attack_ids == 'bonafide') | (labels == 0)

    unique_attacks = sorted(set(attack_ids) - {'-', 'bonafide'})
    for attack in unique_attacks:
        atk_mask = (attack_ids == attack)
        eval_mask = atk_mask | bona_mask
        if eval_mask.sum() < 2 or atk_mask.sum() == 0:
            continue

        sub_labels = labels[eval_mask]
        sub_scores = scores[eval_mask]
        sub_metrics = compute_all_metrics(sub_labels, sub_scores, threshold=threshold)

        results[attack] = {
            'eer': sub_metrics['eer'],
            'accuracy': sub_metrics['accuracy'],
            'precision': sub_metrics['precision'],
            'recall': sub_metrics['recall'],
            'f1': sub_metrics['f1'],
            'roc_auc': sub_metrics['roc_auc'],
            'n_spoof': int(atk_mask.sum()),
            'n_total': int(eval_mask.sum())
        }
    return results


def compute_unseen_attack_breakdown(labels, scores, attack_ids, threshold=0.5):
    """
    Explicitly categorizes evaluation attacks into SEEN vs UNSEEN based on ASVspoof 2019 LA protocol:
      - Seen attacks: A16, A19 (share waveform concatenation / vocoder algorithms with train A01-A06)
      - Unseen attacks: A07, A08, A09, A10, A11, A12, A13, A14, A15, A17, A18 (unseen generative vocoders)
    """
    labels = np.asarray(labels)
    scores = np.asarray(scores)
    attack_ids = np.asarray(attack_ids)

    seen_attack_set = {'A16', 'A19'}
    unseen_attack_set = {'A07', 'A08', 'A09', 'A10', 'A11', 'A12', 'A13', 'A14', 'A15', 'A17', 'A18'}

    bona_mask = (labels == 0)
    seen_mask = np.isin(attack_ids, list(seen_attack_set)) | bona_mask
    unseen_mask = np.isin(attack_ids, list(unseen_attack_set)) | bona_mask

    seen_metrics = compute_all_metrics(labels[seen_mask], scores[seen_mask], threshold=threshold) if seen_mask.sum() > 0 else {}
    unseen_metrics = compute_all_metrics(labels[unseen_mask], scores[unseen_mask], threshold=threshold) if unseen_mask.sum() > 0 else {}

    return {
        'seen_summary': seen_metrics,
        'unseen_summary': unseen_metrics,
        'seen_attack_ids': sorted(seen_attack_set),
        'unseen_attack_ids': sorted(unseen_attack_set)
    }


def format_metrics_table(m, title='Evaluation Results'):
    tau_str = f"tau*={m.get('eer_threshold', float('nan')):.4f} | used={m.get('threshold_used', 0.5):.4f}"
    return '\n'.join([
        '=' * 60,
        f'  {title}',
        '=' * 60,
        f"  Accuracy  : {m['accuracy']*100:7.2f}%",
        f"  Precision : {m['precision']*100:7.2f}%",
        f"  Recall    : {m['recall']*100:7.2f}%",
        f"  F1 Score  : {m['f1']*100:7.2f}%",
        f"  ROC-AUC   : {m['roc_auc']*100:7.2f}%",
        f"  EER       : {m['eer']*100:7.2f}%  ({tau_str})",
        '-' * 60,
        f"  P_fa      : {m['pfa']*100:7.2f}%",
        f"  P_miss    : {m['pmiss']*100:7.2f}%",
        '-' * 60,
        f"  TP={m['tp']:6d}  FP={m['fp']:6d}",
        f"  FN={m['fn']:6d}  TN={m['tn']:6d}  (N={m.get('n_total', m['tp']+m['tn']+m['fp']+m['fn'])})",
        '=' * 60,
    ])


def format_per_attack_table(per_attack_dict, title='TABLE A: Per-Attack Evaluation Results'):
    lines = [
        '=' * 65,
        f'  {title}',
        '=' * 65,
        f"  {'Attack':<10} {'EER (%)':>10} {'Acc (%)':>10} {'F1 (%)':>10} {'AUC (%)':>10} {'N':>8}",
        '-' * 65,
    ]
    for attack in sorted(per_attack_dict):
        r = per_attack_dict[attack]
        lines.append(
            f"  {attack:<10} {r['eer']*100:>10.2f} {r['accuracy']*100:>10.2f} "
            f"{r['f1']*100:>10.2f} {r['roc_auc']*100:>10.2f} {r['n_total']:>8}"
        )
    lines.append('=' * 65)
    return '\n'.join(lines)


def format_unseen_attack_table(unseen_dict, title='TABLE B: Seen vs Unseen Attack Summary'):
    seen = unseen_dict.get('seen_summary', {})
    unseen = unseen_dict.get('unseen_summary', {})
    lines = [
        '=' * 65,
        f'  {title}',
        '=' * 65,
        f"  {'Category':<22} {'Accuracy':>10} {'F1':>10} {'ROC-AUC':>10} {'EER (%)':>10}",
        '-' * 65,
    ]
    if seen:
        lines.append(
            f"  {'Seen Attacks (A16,A19)':<22} {seen['accuracy']*100:>9.2f}% "
            f"{seen['f1']*100:>9.2f}% {seen['roc_auc']*100:>9.2f}% {seen['eer']*100:>9.2f}%"
        )
    if unseen:
        lines.append(
            f"  {'Unseen Attacks (A07-A18)':<22} {unseen['accuracy']*100:>9.2f}% "
            f"{unseen['f1']*100:>9.2f}% {unseen['roc_auc']*100:>9.2f}% {unseen['eer']*100:>9.2f}%"
        )
    lines.append('=' * 65)
    return '\n'.join(lines)


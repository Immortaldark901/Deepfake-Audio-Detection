"""
Advanced Loss Functions for Audio Deepfake and Spoof Detection.
Includes:
1. ArcFace (Additive Angular Margin Loss)
2. AM-Softmax (Additive Margin Softmax)
3. Focal Loss for Class Imbalance

References:
- Deng et al., "ArcFace: Additive Angular Margin Loss for Deep Face Recognition", CVPR 2019.
- Wang et al., "Additive Margin Softmax for Face Verification", IEEE SPL 2018.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class ArcMarginProduct(nn.Module):
    """
    ArcFace: Additive Angular Margin Head for metric feature learning.
    Applies an angular margin m to the target class angle theta on a normalized hypersphere.
    
    Formula:
        cos(theta_y + m) = cos(theta_y) * cos(m) - sin(theta_y) * sin(m)
    """
    def __init__(self, in_features, out_features=2, s=30.0, m=0.35, easy_margin=False):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.s = s
        self.m = m
        self.easy_margin = easy_margin

        self.weight = nn.Parameter(torch.FloatTensor(out_features, in_features))
        nn.init.xavier_uniform_(self.weight)

        self.cos_m = math.cos(m)
        self.sin_m = math.sin(m)
        self.th = math.cos(math.pi - m)
        self.mm = math.sin(math.pi - m) * m

    def forward(self, input_features, label=None):
        """
        Args:
            input_features (torch.Tensor): Feature embeddings of shape (Batch, in_features)
            label (torch.Tensor, optional): Ground-truth class labels of shape (Batch,)
            
        Returns:
            torch.Tensor: Scaled cosine logits of shape (Batch, out_features)
        """
        # Normalize features and weights onto unit hypersphere
        cosine = F.linear(F.normalize(input_features), F.normalize(self.weight))
        
        # During inference or when no labels provided, return scaled cosine similarity
        if label is None or not self.training:
            return cosine * self.s

        sine = torch.sqrt(torch.clamp(1.0 - torch.pow(cosine, 2), 1e-7, 1.0))
        phi = cosine * self.cos_m - sine * self.sin_m

        if self.easy_margin:
            phi = torch.where(cosine > 0, phi, cosine)
        else:
            phi = torch.where(cosine > self.th, phi, cosine - self.mm)

        one_hot = torch.zeros_like(cosine)
        one_hot.scatter_(1, label.view(-1, 1).long(), 1)
        output = (one_hot * phi) + ((1.0 - one_hot) * cosine)
        output *= self.s
        return output


class FocalLoss(nn.Module):
    """
    Focal Loss for addressing class imbalance between bonafide and spoof utterances.
    Loss(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)
    """
    def __init__(self, alpha=None, gamma=2.0, reduction='mean'):
        super().__init__()
        self.alpha = alpha  # class weights tensor
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', weight=self.alpha)
        pt = torch.exp(-ce_loss)
        focal_loss = ((1.0 - pt) ** self.gamma) * ce_loss

        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        return focal_loss

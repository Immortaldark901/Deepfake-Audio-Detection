"""
Dual-Stream Acoustic Deepfake Detector Network.
Fuses Stream A (LFCC-MLP) and Stream B (4-Block CNN) to exploit complementary
linear-frequency cepstral and psychoacoustic time-frequency evidence.
Total parameters: < 0.5M.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .lfcc_mlp import LFCC_MLP
from .cnn_stream import Lightweight4BlockCNN
try:
    from ..losses import ArcMarginProduct
except (ImportError, ValueError):
    try:
        from audio_deepfake_detector.losses import ArcMarginProduct
    except (ImportError, ValueError):
        from losses import ArcMarginProduct


class CrossAttentionFusion(nn.Module):
    """
    Lightweight Cross-Attention Module for bidirectional feature interaction between
    temporal Log-Mel embedding (128-dim) and spectral LFCC embedding (32-dim).
    """
    def __init__(self, dim_a=32, dim_b=128, num_heads=2):
        super().__init__()
        self.proj_a = nn.Linear(dim_a, dim_b)
        self.attn = nn.MultiheadAttention(embed_dim=dim_b, num_heads=num_heads, batch_first=True)
        self.norm = nn.LayerNorm(dim_b)

    def forward(self, embed_a, embed_b):
        # embed_a: (Batch, 32) -> (Batch, 1, 128)
        # embed_b: (Batch, 128) -> (Batch, 1, 128)
        proj_a = self.proj_a(embed_a).unsqueeze(1)
        b = embed_b.unsqueeze(1)
        attn_out, _ = self.attn(query=b, key=proj_a, value=proj_a)
        fused = self.norm((b + attn_out).squeeze(1))
        return torch.cat([embed_a, fused], dim=1)


class DualStreamDetector(nn.Module):
    """
    Lightweight Dual-Stream Deepfake Detector.
    
    Architecture:
      Stream A: LFCC (120) -> LFCC_MLP -> 32-dim embedding
      Stream B: Log-Mel (1, 128, 126) -> 4-Block CNN (with optional SE attention) -> 128-dim embedding
      Fusion: Concat(32 + 128 = 160) -> Linear(160, 64) -> BN -> ReLU -> Dropout(0.2) -> Linear(64, 2)
    """
    def __init__(
        self,
        lfcc_dim=120,
        mel_channels=1,
        num_classes=2,
        dropout=0.2,
        use_se=False,
        use_arcface=False,
        use_attention_fusion=False
    ):
        super().__init__()
        self.num_classes = num_classes
        self.use_arcface = use_arcface
        self.use_attention_fusion = use_attention_fusion
        
        # Stream A (LFCC-MLP Backbone) — classifier head is bypassed; only embedding used
        self.stream_a = LFCC_MLP(
            input_dim=lfcc_dim,
            hidden_dim=64,
            embed_dim=32,
            return_embeddings=True
        )
        for p in self.stream_a.classifier.parameters():
            p.requires_grad = False
        
        # Stream B (Lightweight 4-Block CNN Backbone with optional SE)
        self.stream_b = Lightweight4BlockCNN(
            in_channels=mel_channels,
            embed_dim=128,
            return_embeddings=True,
            use_se=use_se
        )
        for p in self.stream_b.classifier.parameters():
            p.requires_grad = False
        
        # Optional Cross-Attention Fusion
        if use_attention_fusion:
            self.cross_attn = CrossAttentionFusion(dim_a=32, dim_b=128, num_heads=2)
            fusion_in_dim = 32 + 128
        else:
            self.cross_attn = None
            fusion_in_dim = 32 + 128  # 160

        # Fusion Head (Maintains exact key naming with standard Sequential)
        self.fusion_head = nn.Sequential(
            nn.Linear(fusion_in_dim, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(64, num_classes)
        )

        # Optional ArcFace Metric Head
        if use_arcface:
            self.arc_classifier = ArcMarginProduct(in_features=64, out_features=num_classes, s=30.0, m=0.35)
            # Freeze the dormant standard linear layer when ArcFace head is active
            for p in self.fusion_head[4].parameters():
                p.requires_grad = False
        else:
            self.arc_classifier = None

    def forward(self, lfcc, mel, labels=None, retain_cam_maps=False):
        """
        Forward pass of the dual-stream network.
        
        Args:
            lfcc (torch.Tensor): LFCC feature tensor of shape (Batch, 120)
            mel (torch.Tensor): Log-Mel spectrogram tensor of shape (Batch, 1, 128, 126)
            labels (torch.Tensor, optional): Target labels for ArcFace margin calculation.
            retain_cam_maps (bool): Retain CNN feature maps & gradient hooks for Grad-CAM.
            
        Returns:
            torch.Tensor: Classification logits of shape (Batch, 2)
        """
        # Extract stream embeddings
        embed_a = self.stream_a(lfcc)
        embed_b = self.stream_b(mel, retain_cam_maps=retain_cam_maps)
        
        # Feature Fusion
        if self.cross_attn is not None:
            fused = self.cross_attn(embed_a, embed_b)
        else:
            fused = torch.cat([embed_a, embed_b], dim=1)
        
        # Classification Head
        if self.arc_classifier is not None:
            # Pass through layers 0-3 of fusion_head (Linear -> BN -> ReLU -> Dropout)
            feat = self.fusion_head[:4](fused)
            logits = self.arc_classifier(feat, labels)
        else:
            logits = self.fusion_head(fused)

        return logits

    def predict_proba(self, lfcc, mel):
        """
        Computes posterior probability P(Y=1 | x) for spoof detection.
        
        Returns:
            torch.Tensor: Spoof probabilities of shape (Batch,)
        """
        self.eval()
        with torch.no_grad():
            logits = self.forward(lfcc, mel)
            probs = F.softmax(logits, dim=-1)
            # Class 1 is spoof (as defined in paper: Y=1 denotes spoofed speech)
            return probs[:, 1]

    def count_parameters(self):
        """
        Returns total and trainable parameter counts.
        """
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return total, trainable

    def summary(self):
        """
        Prints structured architecture and parameter breakdown.
        """
        total_p, train_p = self.count_parameters()
        stream_a_p = sum(p.numel() for p in self.stream_a.parameters())
        stream_b_p = sum(p.numel() for p in self.stream_b.parameters())
        fusion_p = sum(p.numel() for p in self.fusion_head.parameters())
        
        report = (
            "=" * 55 + "\n"
            "   DUAL-STREAM AUDIO DEEPFAKE DETECTOR SUMMARY\n"
            "=" * 55 + "\n"
            f" Stream A (LFCC-MLP) Parameters    : {stream_a_p:>10,}\n"
            f" Stream B (4-Block CNN) Parameters : {stream_b_p:>10,}\n"
            f" Fusion Head Parameters            : {fusion_p:>10,}\n"
            "-" * 55 + "\n"
            f" TOTAL PARAMETERS                  : {total_p:>10,} ({total_p/1e6:.3f}M)\n"
            f" TRAINABLE PARAMETERS              : {train_p:>10,} ({train_p/1e6:.3f}M)\n"
            f" Budget Compliance (< 0.5M)        : {'PASS [VERIFIED]' if total_p < 500000 else 'FAIL'}\n"
            "=" * 55
        )
        return report

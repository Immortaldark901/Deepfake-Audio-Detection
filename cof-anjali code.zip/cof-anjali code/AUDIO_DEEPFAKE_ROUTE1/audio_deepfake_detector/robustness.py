"""
Phase 7: Acoustic Stress Testing & Continuous AWGN SNR Sweep.
Injects calibrated Additive White Gaussian Noise (AWGN) at precise SNR levels
[Clean, 30 dB, 20 dB, 10 dB, 0 dB], measures achieved SNR, and profiles degradation
of Accuracy, Precision, Recall, F1, ROC-AUC, and EER using the frozen DEV threshold.
"""

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from .evaluate import compute_all_metrics


def inject_awgn(waveform, snr_db, clip=True):
    """
    Injects calibrated Additive White Gaussian Noise (AWGN) into audio waveform.
    Calculates and returns both the noisy waveform and the actual achieved SNR in dB.
    
    Formula:
        sigma_noise^2 = sigma_signal^2 / 10^(SNR / 10)
        w[n] ~ N(0, sigma_noise^2)
        y[n] = x[n] + w[n]
        
    Args:
        waveform (np.ndarray or torch.Tensor): 1D audio waveform (Samples,)
        snr_db (float or None): Signal-to-Noise Ratio in dB. If None or np.inf, returns clean.
        clip (bool): Whether to clip output to [-1.0, 1.0] range.
        
    Returns:
        tuple: (noisy_waveform, achieved_snr_db)
    """
    if snr_db is None or np.isinf(snr_db):
        return waveform, float('inf')
        
    is_torch = isinstance(waveform, torch.Tensor)
    if is_torch:
        x = waveform.cpu().numpy()
    else:
        x = np.copy(waveform)
        
    # Calculate signal power
    sig_power = np.mean(x ** 2)
    if sig_power <= 1e-12:
        return waveform, float('inf')
        
    # Calculate required noise power for target SNR
    noise_power = sig_power / (10.0 ** (snr_db / 10.0))
    noise_std = np.sqrt(noise_power)
    
    # Generate Gaussian noise
    noise = np.random.normal(0, noise_std, size=x.shape).astype(x.dtype)
    noisy_x = x + noise
    
    # Clip if requested and compute actual achieved SNR
    if clip:
        noisy_x = np.clip(noisy_x, -1.0, 1.0)
        
    actual_noise = noisy_x - x
    actual_noise_power = np.mean(actual_noise ** 2)
    if actual_noise_power > 1e-12:
        achieved_snr = 10.0 * np.log10(sig_power / actual_noise_power)
    else:
        achieved_snr = float('inf')
    
    if is_torch:
        noisy_tensor = torch.from_numpy(noisy_x).to(waveform.device)
        return noisy_tensor, float(achieved_snr)
    return noisy_x, float(achieved_snr)


def run_robustness_sweep(
    model,
    dataset,
    feature_extractor,
    snr_levels=[np.inf, 30.0, 20.0, 10.0, 0.0],
    threshold=0.5,
    device='cpu',
    max_samples=None
):
    """
    Evaluates a trained model across a sweep of calibrated SNR conditions using the FROZEN DEV threshold.
    
    Args:
        model: Trained detector (DualStreamDetector or baseline)
        dataset: Dataset providing raw audio waveforms and labels
        feature_extractor: DualStreamFeatureExtractor
        snr_levels: List of SNRs in dB to test [inf, 30, 20, 10, 0]
        threshold: Frozen decision threshold tau* selected on DEV
        device: 'cuda' or 'cpu'
        max_samples: Optional cap on test samples
        
    Returns:
        dict: Mapping snr_label -> complete metrics dict + achieved_snr
    """
    model.eval()
    if feature_extractor:
        feature_extractor.eval()
        
    results = {}
    num_samples = len(dataset) if max_samples is None else min(len(dataset), max_samples)
    
    for snr in snr_levels:
        snr_label = "Clean" if np.isinf(snr) else f"{int(snr)}dB"
        y_true = []
        y_scores = []
        achieved_snrs = []
        
        for idx in range(num_samples):
            item = dataset[idx]
            waveform = item['waveform'] if 'waveform' in item else item.get('audio')
            label = item['label']
            if isinstance(label, torch.Tensor):
                label = label.item()
                
            # Inject AWGN at target SNR and record achieved SNR
            noisy_audio, actual_snr = inject_awgn(waveform, snr, clip=True)
            if not np.isinf(actual_snr):
                achieved_snrs.append(actual_snr)
                
            # Convert to torch tensor of shape (1, Samples)
            if not isinstance(noisy_audio, torch.Tensor):
                noisy_tensor = torch.from_numpy(noisy_audio).float()
            else:
                noisy_tensor = noisy_audio.float()
                
            if noisy_tensor.ndim == 1:
                noisy_tensor = noisy_tensor.unsqueeze(0)
                
            # Feature extraction on noisy audio waveform
            with torch.no_grad():
                lfcc, mel = feature_extractor(noisy_tensor.to(device))
                logits = model(lfcc, mel)
                probs = torch.softmax(logits, dim=-1)
                spoof_prob = probs[0, 1].item()
                
            y_true.append(label)
            y_scores.append(spoof_prob)
            
        metrics = compute_all_metrics(np.array(y_true), np.array(y_scores), threshold=threshold)
        metrics['target_snr_db'] = snr
        metrics['mean_achieved_snr_db'] = float(np.mean(achieved_snrs)) if len(achieved_snrs) > 0 else float('inf')
        results[snr_label] = metrics
        
    return results


def format_robustness_table(sweep_results, title="TABLE C: AWGN Acoustic Robustness Evaluation"):
    """
    Formats the robustness results into Section 23 Table C format.
    """
    lines = [
        '=' * 75,
        f'  {title}',
        '=' * 75,
        f"  {'Condition':<12} {'Target SNR':>12} {'Achieved SNR':>14} {'Accuracy':>10} {'F1':>10} {'ROC-AUC':>10} {'EER (%)':>10}",
        '-' * 75,
    ]
    for snr_key, m in sweep_results.items():
        cond_str = "Clean" if snr_key == "Clean" else f"AWGN {snr_key}"
        target_str = "Clean" if snr_key == "Clean" else f"{int(m['target_snr_db'])} dB"
        achieved_str = "N/A" if np.isinf(m['mean_achieved_snr_db']) else f"{m['mean_achieved_snr_db']:.2f} dB"
        lines.append(
            f"  {cond_str:<12} {target_str:>12} {achieved_str:>14} "
            f"{m['accuracy']*100:>9.2f}% {m['f1']*100:>9.2f}% {m['roc_auc']*100:>9.2f}% {m['eer']*100:>9.2f}%"
        )
    lines.append('=' * 75)
    return '\n'.join(lines)


def plot_robustness_curves(sweep_results, title="Acoustic Stress Testing (AWGN SNR Sweep)", save_path=None):
    """
    Generates a 2-panel figure showing EER and ROC-AUC degradation across SNR levels.
    """
    snr_keys = list(sweep_results.keys())
    eers = [sweep_results[k]['eer'] * 100.0 for k in snr_keys]
    aucs = [sweep_results[k]['roc_auc'] * 100.0 for k in snr_keys]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    # 1. EER Curve
    ax1.plot(snr_keys, eers, marker='o', color='#e74c3c', linewidth=2.5, markersize=8)
    ax1.set_title("Equal Error Rate (EER %) vs SNR", fontsize=11, fontweight='bold')
    ax1.set_xlabel("Noise Condition / SNR")
    ax1.set_ylabel("EER (%) — Lower is Better")
    ax1.grid(True, linestyle='--', alpha=0.5)
    for i, txt in enumerate(eers):
        ax1.annotate(f"{txt:.2f}%", (snr_keys[i], eers[i]), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=9)
        
    # 2. ROC-AUC Curve
    ax2.plot(snr_keys, aucs, marker='s', color='#2980b9', linewidth=2.5, markersize=8)
    ax2.set_title("ROC-AUC (%) vs SNR", fontsize=11, fontweight='bold')
    ax2.set_xlabel("Noise Condition / SNR")
    ax2.set_ylabel("ROC-AUC (%) — Higher is Better")
    ax2.set_ylim([45.0, 102.0])
    ax2.grid(True, linestyle='--', alpha=0.5)
    for i, txt in enumerate(aucs):
        ax2.annotate(f"{txt:.2f}%", (snr_keys[i], aucs[i]), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=9)
        
    fig.suptitle(title, fontsize=13, fontweight='bold')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=200, bbox_inches='tight')
        plt.close()
    return fig


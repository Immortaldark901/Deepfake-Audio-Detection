"""
Unit Tests for Audio Deepfake Detector Enhancements:
- SpecAugment Time/Frequency Masking
- Calibrated On-the-Fly AWGN Waveform Augmentation
- ArcFace and Focal Loss Module
- Squeeze-and-Excitation (SE) Attention & Parameter Budget Compliance (< 0.5M)
- End-to-End Forward/Backward Integration Test
"""

import math
import unittest
import torch
import torch.nn as nn
import torch.nn.functional as F

from audio_deepfake_detector.augmentations import SpecAugment, WaveformAWGNAugmentation
from audio_deepfake_detector.losses import ArcMarginProduct, FocalLoss
from audio_deepfake_detector.models.dual_stream import DualStreamDetector
from audio_deepfake_detector.models.cnn_stream import Lightweight4BlockCNN, SEBlock


class TestEnhancements(unittest.TestCase):

    def test_01_specaugment_shape_and_masking(self):
        """SpecAugment preserves shape and applies masking when training=True."""
        specaug = SpecAugment(freq_mask_param=16, time_mask_param=16, num_freq_masks=2, num_time_masks=2, mask_value=0.0)
        specaug.train()
        
        mel = torch.ones(4, 1, 128, 126)
        aug_mel = specaug(mel)
        
        self.assertEqual(aug_mel.shape, mel.shape)
        # Verify that some values were masked to 0.0
        self.assertTrue((aug_mel == 0.0).any())
        self.assertTrue((aug_mel == 1.0).any())
        
        # In eval mode, no masking should occur
        specaug.eval()
        aug_eval = specaug(mel)
        self.assertTrue(torch.allclose(aug_eval, mel))

    def test_02_waveform_awgn_augmentation(self):
        """Waveform AWGN augmentation injects noise with calibrated SNR."""
        aug = WaveformAWGNAugmentation(p=1.0, min_snr_db=20.0, max_snr_db=20.0)
        aug.train()
        
        t = torch.linspace(0, 1, 16000)
        signal = 0.5 * torch.sin(2 * math.pi * 440 * t).unsqueeze(0)
        noisy = aug(signal)
        
        self.assertEqual(noisy.shape, signal.shape)
        noise = noisy - signal
        sig_p = torch.mean(signal ** 2)
        noise_p = torch.mean(noise ** 2)
        achieved_snr = 10.0 * torch.log10(sig_p / noise_p).item()
        
        self.assertAlmostEqual(achieved_snr, 20.0, delta=1.5)

    def test_03_arcface_loss_and_gradients(self):
        """ArcMarginProduct produces valid logits and supports backprop."""
        head = ArcMarginProduct(in_features=64, out_features=2, s=30.0, m=0.35)
        features = torch.randn(8, 64, requires_grad=True)
        labels = torch.tensor([0, 1, 0, 1, 0, 1, 0, 1])
        
        head.train()
        logits = head(features, labels)
        self.assertEqual(logits.shape, (8, 2))
        
        loss = F.cross_entropy(logits, labels)
        loss.backward()
        self.assertIsNotNone(features.grad)
        self.assertFalse(torch.isnan(loss))

    def test_04_focal_loss(self):
        """Focal Loss computes valid cross-entropy with focusing parameter."""
        focal = FocalLoss(gamma=2.0)
        logits = torch.tensor([[2.0, -1.0], [-1.5, 2.5]])
        labels = torch.tensor([0, 1])
        loss = focal(logits, labels)
        
        self.assertGreater(loss.item(), 0.0)
        self.assertFalse(torch.isnan(loss))

    def test_05_se_attention_and_parameter_budget(self):
        """Enhanced DualStream with SE, ArcFace, and Cross-Attention obeys < 0.5M budget."""
        # Baseline model
        baseline_model = DualStreamDetector(use_se=False, use_arcface=False, use_attention_fusion=False)
        total_base, train_base = baseline_model.count_parameters()
        self.assertLess(total_base, 500000)
        self.assertAlmostEqual(train_base, 118000, delta=5000)
        
        # Enhanced model with SE Attention
        se_model = DualStreamDetector(use_se=True, use_arcface=False, use_attention_fusion=False)
        total_se, train_se = se_model.count_parameters()
        self.assertLess(total_se, 500000)
        
        # Enhanced model with SE + ArcFace + CrossAttention
        full_enhanced = DualStreamDetector(use_se=True, use_arcface=True, use_attention_fusion=True)
        total_full, train_full = full_enhanced.count_parameters()
        self.assertLess(total_full, 500000)

    def test_06_forward_backward_dual_stream_enhanced(self):
        """Complete forward/backward pass with dual stream + SE + ArcFace."""
        model = DualStreamDetector(use_se=True, use_arcface=True)
        lfcc = torch.randn(4, 120)
        mel = torch.randn(4, 1, 128, 126)
        labels = torch.tensor([0, 1, 0, 1])
        
        logits = model(lfcc, mel, labels=labels)
        self.assertEqual(logits.shape, (4, 2))
        
        loss = F.cross_entropy(logits, labels)
        loss.backward()
        
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.assertIsNotNone(param.grad, f"Parameter {name} has no gradient!")


if __name__ == '__main__':
    unittest.main()

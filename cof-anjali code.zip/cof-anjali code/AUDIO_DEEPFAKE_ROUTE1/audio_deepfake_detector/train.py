import os
import random
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from .evaluate import compute_all_metrics, format_metrics_table
from .augmentations import SpecAugment, WaveformAWGNAugmentation
from .losses import FocalLoss


def set_seed(seed=42):
    """
    Sets deterministic random seeds across Python, NumPy, and PyTorch.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def get_class_weights(labels_list, num_classes=2, device='cpu'):
    """
    Computes inverse-frequency class weights to counteract label imbalance.
    ASVspoof 2019 LA train: ~90% spoof, ~10% bonafide.
    """
    counts = np.bincount(labels_list, minlength=num_classes).astype(float)
    total  = counts.sum()
    weights = total / (num_classes * counts)
    weights = weights / weights.sum() * num_classes
    return torch.tensor(weights, dtype=torch.float32).to(device)


def train_one_epoch_neural(
    model,
    loader,
    feature_extractor,
    optimizer,
    criterion,
    device,
    scaler=None,
    spec_augment=None,
    waveform_aug=None
):
    """
    Trains a neural model (DualStream, ResNet-18, or standalone CNN/MLP) for one epoch.
    Supports on-the-fly waveform AWGN augmentation and spectrogram SpecAugment.
    """
    model.train()
    if feature_extractor:
        feature_extractor.eval()

    total_loss = 0.0
    n_batches  = 0

    for batch in loader:
        wav    = batch['waveform'].to(device)
        labels = batch['label'].to(device)

        # Apply Waveform Augmentation if enabled
        if waveform_aug is not None:
            wav = waveform_aug(wav)

        optimizer.zero_grad()

        if feature_extractor is not None:
            with torch.no_grad():
                lfcc, mel = feature_extractor(wav)
            lfcc = lfcc.to(device)
            mel  = mel.to(device)

            # Apply SpecAugment if enabled
            if spec_augment is not None:
                mel = spec_augment(mel)

            # Check if model requires labels during forward (e.g. ArcFace)
            if hasattr(model, 'use_arcface') and model.use_arcface:
                logits = model(lfcc, mel, labels=labels)
            else:
                logits = model(lfcc, mel)

            loss = criterion(logits, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        else:
            logits = model(wav)
            loss   = criterion(logits, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        total_loss += loss.item()
        n_batches  += 1

    return total_loss / max(n_batches, 1)


@torch.no_grad()
def evaluate_neural(model, loader, feature_extractor, device, threshold=None, is_dual_stream=True):
    """
    Evaluates a neural model over a data loader.
    If threshold is None, computes optimal EER threshold; otherwise uses the specified frozen threshold.
    """
    model.eval()
    if feature_extractor:
        feature_extractor.eval()

    all_labels     = []
    all_scores     = []
    all_attack_ids = []

    for batch in loader:
        wav        = batch['waveform'].to(device)
        labels     = batch['label'].cpu().numpy()
        attack_ids = batch['attack_id']

        if feature_extractor is not None:
            lfcc, mel = feature_extractor(wav)
            lfcc = lfcc.to(device)
            mel  = mel.to(device)
            logits = model(lfcc, mel)
        else:
            logits = model(wav)

        probs  = F.softmax(logits, dim=-1)[:, 1]  # P(Y=1|x) = spoof prob
        scores = probs.cpu().numpy()

        all_labels.extend(labels.tolist())
        all_scores.extend(scores.tolist())
        all_attack_ids.extend(attack_ids)

    # Use specified threshold if provided, else compute on scores
    eval_thresh = threshold if threshold is not None else 0.5
    metrics = compute_all_metrics(all_labels, all_scores, threshold=eval_thresh)
    metrics['labels']     = np.array(all_labels)
    metrics['scores']     = np.array(all_scores)
    metrics['attack_ids'] = np.array(all_attack_ids)
    return metrics


def train_neural_model(
    model,
    train_loader,
    val_loader,
    feature_extractor,
    device,
    epochs=30,
    lr=1e-4,
    weight_decay=1e-4,
    class_weights=None,
    use_specaugment=False,
    use_awgn_aug=False,
    loss_type='ce',
    save_dir='checkpoints',
    model_name='model',
    is_dual_stream=True,
    seed=42
):
    """
    Full training loop for neural models.
    Supports SpecAugment, AWGN noise-aware training, Cosine Annealing scheduler,
    and preserves best checkpoint and its DEV optimal decision threshold tau*_DEV.
    """
    set_seed(seed)
    os.makedirs(save_dir, exist_ok=True)

    # Setup loss criterion
    if loss_type == 'focal':
        criterion = FocalLoss(alpha=class_weights.to(device) if class_weights is not None else None)
    else:
        criterion = nn.CrossEntropyLoss(weight=class_weights.to(device) if class_weights is not None else None)

    # Setup optional data augmentations
    spec_augment = SpecAugment(freq_mask_param=16, time_mask_param=16, num_freq_masks=2, num_time_masks=2) if use_specaugment else None
    waveform_aug = WaveformAWGNAugmentation(p=0.4, min_snr_db=15.0, max_snr_db=35.0) if use_awgn_aug else None

    optimizer = torch.optim.AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=lr,
        weight_decay=weight_decay
    )

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)

    history = {
        'train_loss': [], 'val_acc': [], 'val_f1': [],
        'val_auc': [], 'val_eer': [], 'val_precision': [], 'val_recall': []
    }

    best_eer           = float('inf')
    best_epoch         = 0
    best_dev_threshold = 0.5

    print(f"\n{'='*60}")
    print(f"  Training: {model_name}  |  epochs={epochs}  |  lr={lr}")
    print(f"  Augmentations: SpecAugment={use_specaugment}, AWGN_Aug={use_awgn_aug}")
    print(f"  Loss={loss_type}  |  Device: {device}")
    print(f"{'='*60}")

    for epoch in range(1, epochs + 1):
        t0 = time.time()

        train_loss = train_one_epoch_neural(
            model, train_loader, feature_extractor, optimizer, criterion, device,
            spec_augment=spec_augment, waveform_aug=waveform_aug
        )

        val_metrics = evaluate_neural(model, val_loader, feature_extractor, device, threshold=None, is_dual_stream=is_dual_stream)

        scheduler.step()
        elapsed = time.time() - t0

        history['train_loss'].append(train_loss)
        history['val_acc'].append(val_metrics['accuracy'])
        history['val_f1'].append(val_metrics['f1'])
        history['val_auc'].append(val_metrics['roc_auc'])
        history['val_eer'].append(val_metrics['eer'])
        history['val_precision'].append(val_metrics['precision'])
        history['val_recall'].append(val_metrics['recall'])

        print(
            f"  Epoch {epoch:>3}/{epochs}"
            f"  Loss={train_loss:.4f}"
            f"  Val Acc={val_metrics['accuracy']*100:.2f}%"
            f"  F1={val_metrics['f1']*100:.2f}%"
            f"  AUC={val_metrics['roc_auc']*100:.2f}%"
            f"  EER={val_metrics['eer']*100:.2f}% (tau*={val_metrics['eer_threshold']:.4f})"
            f"  [{elapsed:.1f}s]"
        )

        # Save best checkpoint (lowest DEV EER)
        if val_metrics['eer'] < best_eer:
            best_eer           = val_metrics['eer']
            best_epoch         = epoch
            best_dev_threshold = val_metrics['eer_threshold']
            ckpt_path          = os.path.join(save_dir, f"{model_name}_best.pth")
            torch.save({
                'epoch':              epoch,
                'model_state':        model.state_dict(),
                'optimizer':          optimizer.state_dict(),
                'best_eer':           best_eer,
                'best_dev_threshold': best_dev_threshold,
                'val_metrics':        val_metrics,
                'seed':               seed,
                'lr':                 lr,
                'weight_decay':       weight_decay,
                'use_specaugment':    use_specaugment,
                'use_awgn_aug':       use_awgn_aug,
                'loss_type':          loss_type
            }, ckpt_path)

    print(f"\n  Best EER={best_eer*100:.2f}% at epoch {best_epoch} (DEV tau*={best_dev_threshold:.4f})")
    print(f"  Checkpoint saved: {os.path.join(save_dir, model_name + '_best.pth')}")

    history['best_eer']           = best_eer
    history['best_epoch']         = best_epoch
    history['best_dev_threshold'] = best_dev_threshold
    return history


def train_gmm_baseline(
    gmm_classifier,
    feature_extractor_fn,
    train_samples,
    verbose=True
):
    """
    Trains a GMM baseline model (M1 LFCC-GMM or M2 CQCC-GMM).
    """
    from .dataset import load_audio_file

    X_bona, X_spoof = [], []

    for i, sample in enumerate(train_samples):
        if verbose and (i % 500 == 0):
            print(f"  Extracting features [{i}/{len(train_samples)}]...", flush=True)

        wav = load_audio_file(sample['path'])
        feat = feature_extractor_fn(wav.unsqueeze(0))

        if isinstance(feat, torch.Tensor):
            feat = feat.squeeze(0).numpy()

        if sample['label'] == 0:
            X_bona.append(feat)
        else:
            X_spoof.append(feat)

    X_bona  = np.vstack(X_bona)
    X_spoof = np.vstack(X_spoof)

    gmm_classifier.fit(X_bona, X_spoof, verbose=verbose)
    return gmm_classifier


def evaluate_gmm_baseline(gmm_classifier, feature_extractor_fn, eval_samples, verbose=True):
    """
    Evaluates a fitted GMM baseline on evaluation samples.
    """
    from .dataset import load_audio_file

    all_labels, all_scores, all_attack_ids = [], [], []

    for i, sample in enumerate(eval_samples):
        if verbose and (i % 2000 == 0):
            print(f"  Evaluating GMM [{i}/{len(eval_samples)}]...", flush=True)

        wav  = load_audio_file(sample['path'])
        feat = feature_extractor_fn(wav.unsqueeze(0))

        if isinstance(feat, torch.Tensor):
            feat = feat.squeeze(0).numpy()

        score = float(gmm_classifier.score(feat.reshape(1, -1))[0])
        all_labels.append(sample['label'])
        all_scores.append(score)
        all_attack_ids.append(sample.get('attack_id', '-'))

    metrics = compute_all_metrics(all_labels, all_scores)
    metrics['labels']     = np.array(all_labels)
    metrics['scores']     = np.array(all_scores)
    metrics['attack_ids'] = np.array(all_attack_ids)
    return metrics

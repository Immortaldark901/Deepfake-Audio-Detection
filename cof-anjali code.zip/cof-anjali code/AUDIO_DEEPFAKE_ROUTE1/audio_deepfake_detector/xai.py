"""
Explainable AI (XAI) & Attribution Pipeline using Grad-CAM and Raw-Audio Perturbation Masking.
Extracts time-frequency saliency maps from Stream B (4-Block CNN) of the Dual-Stream network.
Performs Attribution Validation via Perturbation Masking on the RAW AUDIO WAVEFORM:
  Raw Audio -> Frequency-Band Masking -> Recompute LFCC & Log-Mel -> Dual-Stream Detector -> Measure Confidence Drop (Delta S).
"""

import numpy as np
import torch
import torch.nn.functional as F
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


class DualStreamGradCAM:
    """
    Grad-CAM extractor tailored for DualStreamDetector (Stream B 4-Block CNN).
    
    Computes class-discriminative localization map L^c_{Grad-CAM} by backpropagating
    the score for target class c into the feature maps of the 4th convolutional block.
    """
    def __init__(self, model):
        self.model = model
        self.model.eval()

    def generate_cam(self, lfcc, mel, target_class=1):
        """
        Generate Grad-CAM heatmap for the given inputs.
        
        Args:
            lfcc (torch.Tensor): LFCC features (1, 120) or (Batch, 120)
            mel (torch.Tensor): Log-Mel spectrogram (1, 1, 128, 126)
            target_class (int): Target class index (1 = Spoof, 0 = Bonafide)
            
        Returns:
            cam (np.ndarray): 2D heatmap resized to match mel shape (128, 126), normalized [0, 1]
            logits (torch.Tensor): Raw classification logits
            pred_prob (float): Posterior probability for target_class
        """
        if lfcc.ndim == 1:
            lfcc = lfcc.unsqueeze(0)
        if mel.ndim == 3:
            mel = mel.unsqueeze(0)
            
        lfcc = lfcc.clone().detach().requires_grad_(False)
        mel = mel.clone().detach().requires_grad_(True)
        
        # Forward pass with cam retention
        self.model.zero_grad()
        logits = self.model(lfcc, mel, retain_cam_maps=True)
        
        probs = F.softmax(logits, dim=-1)
        pred_prob = probs[0, target_class].item()
        
        # Backward pass on target score
        score = logits[0, target_class]
        score.backward()
        
        # Retrieve feature maps and gradients from Stream B
        activations = self.model.stream_b.last_conv_act   # (1, 128, 8, 7)
        gradients = self.model.stream_b.last_conv_grad     # (1, 128, 8, 7)
        
        if activations is None or gradients is None:
            raise RuntimeError("Grad-CAM hooks did not capture activations/gradients. Ensure retain_cam_maps=True.")
            
        # Global average pooling over gradients to compute channel weights alpha_k
        alpha = torch.mean(gradients, dim=(2, 3), keepdim=True)  # (1, 128, 1, 1)
        
        # Weighted combination of feature maps
        cam = torch.sum(alpha * activations, dim=1, keepdim=True)  # (1, 1, 8, 7)
        cam = F.relu(cam)  # Only positive influence
        
        # Upsample CAM to original mel spectrogram dimensions (128, 126)
        cam_upsampled = F.interpolate(
            cam, size=(mel.shape[2], mel.shape[3]), mode='bilinear', align_corners=False
        )
        
        cam_np = cam_upsampled.squeeze().detach().cpu().numpy()
        
        # Normalize to [0, 1]
        c_min, c_max = cam_np.min(), cam_np.max()
        if c_max > c_min:
            cam_np = (cam_np - c_min) / (c_max - c_min)
        else:
            cam_np = np.zeros_like(cam_np)
            
        return cam_np, logits.detach(), pred_prob


def compute_frequency_marginals(cam, sr=16000, n_mels=128, f_max=8000):
    """
    Computes frequency marginal attribution \int L(f, t) dt across mel bands.
    
    Args:
        cam (np.ndarray): Grad-CAM heatmap of shape (128, 126) [Freq, Time]
        sr (int): Sampling rate
        n_mels (int): Number of Mel frequency bins
        f_max (int): Maximum frequency
        
    Returns:
        marginals (np.ndarray): Marginal attribution per frequency bin (128,)
        mel_freqs (np.ndarray): Approximate center frequencies in Hz for each bin
        high_band_ratio (float): Ratio of attribution in upper frequency half (> 4kHz)
    """
    # Average across time dimension
    marginals = np.mean(cam, axis=1)  # Shape: (128,)
    
    # Generate approx Hz values for each mel bin
    mels = np.linspace(0, 2595 * np.log10(1 + f_max / 700), n_mels)
    mel_freqs = 700 * (10 ** (mels / 2595) - 1)
    
    # Calculate ratio of attribution in > 4kHz band (synthetic speech artifact band)
    idx_4k = np.searchsorted(mel_freqs, 4000)
    total_attribution = np.sum(marginals) + 1e-12
    high_band_attribution = np.sum(marginals[idx_4k:])
    high_band_ratio = float(high_band_attribution / total_attribution)
    
    return marginals, mel_freqs, high_band_ratio


def mel_bin_to_hz_range(bin_idx, n_mels=128, f_min=0.0, f_max=8000.0):
    """
    Converts a Mel bin index to its lower and upper frequency boundaries in Hz.
    """
    def hz_to_mel(hz):
        return 2595.0 * np.log10(1.0 + hz / 700.0)
    
    def mel_to_hz(mel):
        return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)
    
    mel_min = hz_to_mel(f_min)
    mel_max = hz_to_mel(f_max)
    mel_points = np.linspace(mel_min, mel_max, n_mels + 2)
    hz_points = mel_to_hz(mel_points)
    
    f_low = float(hz_points[bin_idx])
    f_high = float(hz_points[bin_idx + 2])
    return f_low, f_high


def mask_raw_audio_frequency_bands(waveform, freq_ranges, sr=16000, n_fft=1024, hop_length=160, win_length=400):
    """
    Masks specified frequency ranges in the RAW AUDIO WAVEFORM using STFT band-stop and iSTFT synthesis.
    
    Args:
        waveform (torch.Tensor or np.ndarray): Raw 1D audio waveform (Samples,)
        freq_ranges (list of tuples): List of (f_low, f_high) in Hz to mask out
        sr (int): Sampling rate (16000)
        
    Returns:
        torch.Tensor: Modified raw audio waveform with target frequency bands masked.
    """
    is_numpy = isinstance(waveform, np.ndarray)
    if is_numpy:
        wav = torch.from_numpy(waveform).float()
    else:
        wav = waveform.clone().float()
        
    orig_shape = wav.shape
    if wav.ndim == 1:
        wav = wav.unsqueeze(0)  # (1, Samples)
        
    num_samples = wav.shape[-1]
    window = torch.hann_window(win_length, device=wav.device)
    
    # 1. Forward STFT
    stft = torch.stft(
        wav,
        n_fft=n_fft,
        hop_length=hop_length,
        win_length=win_length,
        window=window,
        return_complex=True,
        center=True,
        pad_mode='reflect'
    )  # Shape: (1, n_fft//2 + 1, Frames)
    
    # 2. Compute frequency per STFT bin
    num_bins = n_fft // 2 + 1
    fft_freqs = torch.linspace(0, sr / 2, num_bins, device=wav.device)
    
    # 3. Apply frequency mask
    mask = torch.ones_like(stft.real)
    for f_low, f_high in freq_ranges:
        bin_mask = (fft_freqs >= f_low) & (fft_freqs <= f_high)
        mask[:, bin_mask, :] = 0.0
        
    stft_masked = stft * mask
    
    # 4. Inverse STFT to synthesize modified raw waveform
    wav_masked = torch.istft(
        stft_masked,
        n_fft=n_fft,
        hop_length=hop_length,
        win_length=win_length,
        window=window,
        center=True,
        length=num_samples
    )
    
    if is_numpy:
        return wav_masked.squeeze().cpu().numpy()
    if len(orig_shape) == 1:
        return wav_masked.squeeze(0)
    return wav_masked


def evaluate_raw_audio_perturbation_masking(
    model,
    feature_extractor,
    waveform,
    cam,
    top_k_bands=30,
    sr=16000,
    target_class=1
):
    """
    Attribution Validation via Perturbation Masking on RAW AUDIO.
    
    Pipeline:
      1. Identify top-k highest attribution Mel bins from Grad-CAM.
      2. Convert Mel bins to frequency boundaries [f_low, f_high] in Hz.
      3. Mask those frequency regions in the RAW AUDIO waveform.
      4. Recompute LFCC (120-dim) and Log-Mel (1, 128, 126) from modified audio.
      5. Pass recomputed features to proposed model.
      6. Measure original confidence S(x), masked confidence S(x_masked), and relative drop Delta S.
      
    Args:
        model: Trained DualStreamDetector
        feature_extractor: DualStreamFeatureExtractor
        waveform (torch.Tensor): Raw audio tensor of shape (64000,) or (1, 64000)
        cam (np.ndarray): Grad-CAM heatmap (128, 126)
        top_k_bands (int): Number of most salient frequency bins to mask
        sr (int): Sampling rate
        target_class (int): 1 = Spoof
        
    Returns:
        dict: {
            'delta_s': float (relative % drop in posterior confidence),
            's_orig': float (original posterior probability),
            's_masked': float (masked posterior probability),
            'masked_waveform': torch.Tensor (modified raw audio),
            'top_freq_ranges_hz': list of (f_low, f_high),
            'high_band_attribution_ratio': float
        }
    """
    model.eval()
    if waveform.ndim == 1:
        waveform = waveform.unsqueeze(0)
        
    device = next(model.parameters()).device
    waveform = waveform.to(device)
    
    # 1. Original features & baseline prediction
    with torch.no_grad():
        lfcc_orig, mel_orig = feature_extractor(waveform)
        logits_orig = model(lfcc_orig, mel_orig)
        s_orig = F.softmax(logits_orig, dim=-1)[0, target_class].item()
        
    # 2. Identify top_k frequency bands from Grad-CAM marginals
    marginals, mel_freqs, high_band_ratio = compute_frequency_marginals(cam, sr=sr, n_mels=128, f_max=sr // 2)
    top_indices = np.argsort(marginals)[::-1][:top_k_bands]
    
    # Convert bins to Hz ranges
    freq_ranges = [mel_bin_to_hz_range(int(idx), n_mels=128, f_min=0.0, f_max=sr / 2.0) for idx in top_indices]
    
    # 3. Mask target frequency regions in RAW AUDIO
    masked_waveform = mask_raw_audio_frequency_bands(waveform, freq_ranges, sr=sr)
    masked_waveform = masked_waveform.to(device)
    
    # 4. Recompute LFCC and Log-Mel features from modified audio
    with torch.no_grad():
        lfcc_masked, mel_masked = feature_extractor(masked_waveform)
        
    # 5. Model prediction on re-extracted features
    with torch.no_grad():
        logits_masked = model(lfcc_masked, mel_masked)
        s_masked = F.softmax(logits_masked, dim=-1)[0, target_class].item()
        
    # 6. Relative confidence drop Delta S
    if s_orig > 1e-6:
        delta_s = ((s_orig - s_masked) / s_orig) * 100.0
    else:
        delta_s = 0.0
        
    return {
        'delta_s': float(delta_s),
        's_orig': float(s_orig),
        's_masked': float(s_masked),
        'masked_waveform': masked_waveform.squeeze(0),
        'top_freq_ranges_hz': freq_ranges,
        'high_band_ratio': float(high_band_ratio)
    }


def evaluate_perturbation_masking(model, lfcc, mel, cam, top_k_bands=30, target_class=1):
    """
    Tensor-level feature masking comparison helper.
    """
    model.eval()
    if lfcc.ndim == 1:
        lfcc = lfcc.unsqueeze(0)
    if mel.ndim == 3:
        mel = mel.unsqueeze(0)
        
    with torch.no_grad():
        logits_orig = model(lfcc, mel)
        s_orig = F.softmax(logits_orig, dim=-1)[0, target_class].item()
        
    marginals = np.mean(cam, axis=1)
    top_indices = np.argsort(marginals)[::-1][:top_k_bands]
    
    min_val = mel.min().item()
    masked_mel = mel.clone()
    for idx in top_indices:
        masked_mel[:, :, idx, :] = min_val
        
    with torch.no_grad():
        logits_masked = model(lfcc, masked_mel)
        s_masked = F.softmax(logits_masked, dim=-1)[0, target_class].item()
        
    if s_orig > 1e-6:
        delta_s = ((s_orig - s_masked) / s_orig) * 100.0
    else:
        delta_s = 0.0
        
    return delta_s, s_orig, s_masked, masked_mel


def plot_gradcam_explanation(mel_np, cam, marginals, mel_freqs, title="Grad-CAM XAI Attribution", save_path=None):
    """
    Creates a publication-grade 3-panel figure:
    1. Log-Mel Spectrogram
    2. Grad-CAM Heatmap Overlay
    3. Frequency Marginal Profile (showing 4-8 kHz high-frequency attribution)
    """
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(15, 4.5), gridspec_kw={'width_ratios': [1, 1, 0.6]})
    
    # 1. Original Spectrogram
    im1 = ax1.imshow(mel_np, origin='lower', aspect='auto', cmap='magma')
    ax1.set_title("Log-Mel Spectrogram (128x126)", fontsize=11, fontweight='bold')
    ax1.set_xlabel("Time Frames")
    ax1.set_ylabel("Mel Frequency Bins")
    plt.colorbar(im1, ax=ax1, fraction=0.046, pad=0.04)
    
    # 2. Grad-CAM Overlay
    ax2.imshow(mel_np, origin='lower', aspect='auto', cmap='gray', alpha=0.5)
    im2 = ax2.imshow(cam, origin='lower', aspect='auto', cmap='jet', alpha=0.6)
    ax2.set_title("Grad-CAM Attribution Overlay", fontsize=11, fontweight='bold')
    ax2.set_xlabel("Time Frames")
    plt.colorbar(im2, ax=ax2, fraction=0.046, pad=0.04)
    
    # 3. Frequency Marginals
    ax3.plot(marginals, np.arange(len(marginals)), color='#e74c3c', linewidth=2)
    ax3.set_title("Frequency Attribution Marginal", fontsize=11, fontweight='bold')
    ax3.set_xlabel("Mean Saliency")
    ax3.set_ylabel("Mel Bins (0 to 8 kHz)")
    ax3.axhspan(64, 127, color='#f39c12', alpha=0.2, label='4-8 kHz Band')
    ax3.legend(loc='upper right', fontsize=8)
    ax3.grid(True, linestyle='--', alpha=0.5)
    
    fig.suptitle(title, fontsize=13, fontweight='bold')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=200, bbox_inches='tight')
        plt.close()
    return fig


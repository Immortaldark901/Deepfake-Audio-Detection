"""
Phase 7: Continuous Acoustic Stress Testing (AWGN SNR Sweep).
Evaluates detector degradation across Clean, 30 dB, 20 dB, 10 dB, 0 dB SNR conditions.
Uses the frozen DEV decision threshold tau*_DEV and measures actual achieved SNR.
"""

import os
import sys
import json
import argparse
import torch
import numpy as np

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from audio_deepfake_detector.models.dual_stream import DualStreamDetector
from audio_deepfake_detector.features import DualStreamFeatureExtractor
from audio_deepfake_detector.dataset import ASVspoof2019LADataset, SyntheticDemoDataset
from audio_deepfake_detector.robustness import run_robustness_sweep, format_robustness_table, plot_robustness_curves


def run_robustness_experiment(
    checkpoint_path=None,
    data_root=None,
    output_dir="results/robustness",
    threshold=None,
    max_samples=200,
    device="cpu"
):
    os.makedirs(output_dir, exist_ok=True)
    device = torch.device(device if torch.cuda.is_available() and device == "cuda" else "cpu")

    print("=" * 65)
    print("   ACOUSTIC STRESS TESTING & CONTINUOUS AWGN SNR SWEEP")
    print("=" * 65)

    model = DualStreamDetector(lfcc_dim=120, mel_channels=1, num_classes=2).to(device)
    dev_threshold = 0.5

    if checkpoint_path and os.path.isfile(checkpoint_path):
        print(f"[*] Loading checkpoint: {checkpoint_path}")
        ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(ckpt.get('model_state', ckpt))
        dev_threshold = ckpt.get('best_dev_threshold', 0.5)
        print(f"[*] Loaded frozen DEV decision threshold tau* = {dev_threshold:.4f}")

    if threshold is not None:
        dev_threshold = threshold
        print(f"[*] Overriding with user threshold tau = {dev_threshold:.4f}")

    model.eval()
    feature_extractor = DualStreamFeatureExtractor(sample_rate=16000).to(device)

    # Prepare dataset
    if data_root and os.path.isdir(data_root):
        from audio_deepfake_detector.kaggle_data import get_la_paths
        paths = get_la_paths(data_root)
        dataset = ASVspoof2019LADataset(paths['eval_protocol'], paths['eval_audio'])
    else:
        print("[*] Using synthetic benchmark samples for robustness profiling...")
        dataset = SyntheticDemoDataset(num_samples=max(max_samples, 40), spoof_ratio=0.5)

    snr_levels = [np.inf, 30.0, 20.0, 10.0, 0.0]
    sweep_results = run_robustness_sweep(
        model=model,
        dataset=dataset,
        feature_extractor=feature_extractor,
        snr_levels=snr_levels,
        threshold=dev_threshold,
        device=device,
        max_samples=max_samples
    )

    # Print Table C
    print("\n" + format_robustness_table(sweep_results))

    # Save plot
    fig_path = os.path.join(output_dir, "robustness_snr_curves.png")
    plot_robustness_curves(sweep_results, save_path=fig_path)
    print(f"[+] Saved robustness curves: {fig_path}")

    # Save JSON results
    json_path = os.path.join(output_dir, "robustness_results.json")
    clean_results = {}
    for k, v in sweep_results.items():
        clean_results[k] = {
            "target_snr_db": v['target_snr_db'] if not np.isinf(v['target_snr_db']) else "Clean",
            "mean_achieved_snr_db": v['mean_achieved_snr_db'] if not np.isinf(v['mean_achieved_snr_db']) else "Clean",
            "accuracy": v['accuracy'],
            "precision": v['precision'],
            "recall": v['recall'],
            "f1": v['f1'],
            "roc_auc": v['roc_auc'],
            "eer": v['eer'],
            "threshold_used": v['threshold_used'],
            "tp": v['tp'], "tn": v['tn'], "fp": v['fp'], "fn": v['fn']
        }
    with open(json_path, "w") as f:
        json.dump(clean_results, f, indent=2)
    print(f"[+] Saved robustness metrics: {json_path}\n")

    return sweep_results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AWGN Robustness Sweep")
    parser.add_argument("--checkpoint", type=str, default=None, help="Model checkpoint path")
    parser.add_argument("--data_root", type=str, default=None, help="Dataset root path")
    parser.add_argument("--output_dir", type=str, default="results/robustness", help="Output directory")
    parser.add_argument("--threshold", type=float, default=None, help="Frozen decision threshold")
    parser.add_argument("--max_samples", type=int, default=200, help="Max test samples")
    parser.add_argument("--device", type=str, default="cpu", help="Device (cuda/cpu)")
    args = parser.parse_args()

    run_robustness_experiment(
        checkpoint_path=args.checkpoint,
        data_root=args.data_root,
        output_dir=args.output_dir,
        threshold=args.threshold,
        max_samples=args.max_samples,
        device=args.device
    )

"""
Phase 6: Explainable AI (XAI) & Attribution Validation Pipeline.
Generates Grad-CAM saliency heatmaps on Stream B (4-Block CNN) and conducts
Attribution Validation via Perturbation Masking on the RAW AUDIO WAVEFORM.
"""

import os
import sys
import json
import argparse
import torch
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from audio_deepfake_detector.models.dual_stream import DualStreamDetector
from audio_deepfake_detector.features import DualStreamFeatureExtractor
from audio_deepfake_detector.dataset import ASVspoof2019LADataset, SyntheticDemoDataset, load_audio_file
from audio_deepfake_detector.xai import (
    DualStreamGradCAM, compute_frequency_marginals,
    evaluate_raw_audio_perturbation_masking, plot_gradcam_explanation
)


def run_xai_audit(
    checkpoint_path=None,
    data_root=None,
    output_dir="results/xai",
    num_samples=50,
    top_k_bands=30,
    device="cpu"
):
    os.makedirs(output_dir, exist_ok=True)
    device = torch.device(device if torch.cuda.is_available() and device == "cuda" else "cpu")

    print("=" * 65)
    print("   EXPLAINABLE AI & RAW-AUDIO PERTURBATION MASKING AUDIT")
    print("=" * 65)

    # 1. Initialize proposed model
    model = DualStreamDetector(lfcc_dim=120, mel_channels=1, num_classes=2).to(device)
    if checkpoint_path and os.path.isfile(checkpoint_path):
        print(f"[*] Loading checkpoint: {checkpoint_path}")
        ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(ckpt.get('model_state', ckpt))
    else:
        print("[!] No checkpoint provided — running in architecture audit mode with initialized weights.")
    model.eval()

    feature_extractor = DualStreamFeatureExtractor(sample_rate=16000).to(device)
    gradcam = DualStreamGradCAM(model)

    # 2. Prepare sample dataset
    if data_root and os.path.isdir(data_root):
        from audio_deepfake_detector.kaggle_data import get_la_paths
        paths = get_la_paths(data_root)
        dataset = ASVspoof2019LADataset(paths['eval_protocol'], paths['eval_audio'])
    else:
        print("[*] Using synthetic benchmark samples for attribution validation...")
        dataset = SyntheticDemoDataset(num_samples=max(num_samples, 20), spoof_ratio=0.8)

    sample_count = min(len(dataset), num_samples)
    print(f"[*] Auditing {sample_count} audio samples for functional frequency attribution...")

    orig_confs = []
    masked_confs = []
    delta_s_list = []
    high_band_ratios = []
    correct_before = 0
    correct_after = 0
    analyzed_spoofs = 0

    first_plot_saved = False

    for idx in range(sample_count):
        item = dataset[idx]
        wav = item['waveform'] if 'waveform' in item else load_audio_file(item['path'])
        label = item['label']
        if isinstance(label, torch.Tensor):
            label = label.item()

        if wav.ndim == 1:
            wav_tensor = wav.unsqueeze(0).to(device)
        else:
            wav_tensor = wav.to(device)

        # Extract features
        with torch.no_grad():
            lfcc, mel = feature_extractor(wav_tensor)

        # Generate Grad-CAM for spoof class (target_class=1)
        cam, _, prob = gradcam.generate_cam(lfcc, mel, target_class=1)

        # Only evaluate perturbation masking on spoof utterances
        if label == 1:
            analyzed_spoofs += 1
            if prob >= 0.5:
                correct_before += 1

            # Run RAW AUDIO perturbation masking
            result = evaluate_raw_audio_perturbation_masking(
                model=model,
                feature_extractor=feature_extractor,
                waveform=wav_tensor,
                cam=cam,
                top_k_bands=top_k_bands,
                sr=16000,
                target_class=1
            )

            orig_confs.append(result['s_orig'])
            masked_confs.append(result['s_masked'])
            delta_s_list.append(result['delta_s'])
            high_band_ratios.append(result['high_band_ratio'])

            if result['s_masked'] >= 0.5:
                correct_after += 1

            # Save first sample 3-panel figure
            if not first_plot_saved:
                marginals, freqs, _ = compute_frequency_marginals(cam, sr=16000)
                mel_np = mel.squeeze().detach().cpu().numpy()
                fig_path = os.path.join(output_dir, "gradcam_3panel_explanation.png")
                plot_gradcam_explanation(
                    mel_np, cam, marginals, freqs,
                    title="Grad-CAM Saliency & High-Frequency Attribution Profile",
                    save_path=fig_path
                )
                print(f"[+] Saved Grad-CAM figure: {fig_path}")
                first_plot_saved = True

    mean_orig_conf = float(np.mean(orig_confs)) if orig_confs else 0.0
    mean_masked_conf = float(np.mean(masked_confs)) if masked_confs else 0.0
    mean_delta_s = float(np.mean(delta_s_list)) if delta_s_list else 0.0
    mean_high_band = float(np.mean(high_band_ratios)) if high_band_ratios else 0.0

    print("\n" + "=" * 65)
    print("   TABLE D: ATTRIBUTION VALIDATION VIA RAW-AUDIO MASKING")
    print("=" * 65)
    print(f"  Samples Analyzed (Spoof)     : {analyzed_spoofs}")
    print(f"  Correct Before Masking       : {correct_before} / {analyzed_spoofs} ({correct_before/max(analyzed_spoofs,1)*100:.1f}%)")
    print(f"  Correct After Masking        : {correct_after} / {analyzed_spoofs} ({correct_after/max(analyzed_spoofs,1)*100:.1f}%)")
    print(f"  Mean Original Confidence     : {mean_orig_conf*100:6.2f}%")
    print(f"  Mean Masked Confidence       : {mean_masked_conf*100:6.2f}%")
    print(f"  Mean Relative Drop (Delta S) : {mean_delta_s:6.2f}%")
    print(f"  Attribution in 4-8 kHz Band  : {mean_high_band*100:6.2f}%")
    print("=" * 65 + "\n")

    # Save summary JSON
    summary_data = {
        "analyzed_spoofs": analyzed_spoofs,
        "correct_before": correct_before,
        "correct_after": correct_after,
        "mean_original_confidence": mean_orig_conf,
        "mean_masked_confidence": mean_masked_conf,
        "mean_relative_drop_delta_s": mean_delta_s,
        "mean_high_band_attribution_ratio": mean_high_band
    }
    with open(os.path.join(output_dir, "xai_attribution_summary.json"), "w") as f:
        json.dump(summary_data, f, indent=2)

    return summary_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Explainable AI & Perturbation Masking")
    parser.add_argument("--checkpoint", type=str, default=None, help="Model checkpoint path")
    parser.add_argument("--data_root", type=str, default=None, help="Dataset root path")
    parser.add_argument("--output_dir", type=str, default="results/xai", help="Output directory")
    parser.add_argument("--num_samples", type=int, default=50, help="Number of samples to audit")
    parser.add_argument("--device", type=str, default="cpu", help="Device (cuda/cpu)")
    args = parser.parse_args()

    run_xai_audit(
        checkpoint_path=args.checkpoint,
        data_root=args.data_root,
        output_dir=args.output_dir,
        num_samples=args.num_samples,
        device=args.device
    )

"""
Dataset Verification & Integrity Audit Script for ASVspoof 2019 LA.
Verifies file presence, protocol mappings, speaker isolation, and zero-leakage constraints.
"""

import os
import sys
import argparse

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from audio_deepfake_detector.kaggle_data import download_asvspoof2019, get_la_paths
from audio_deepfake_detector.dataset import check_dataset_integrity, parse_protocol_file


def verify_dataset(data_root=None):
    print("=" * 65)
    print("   ASVSPOOF 2019 LA DATASET INTEGRITY & ISOLATION AUDIT")
    print("=" * 65)

    if data_root is None:
        print("[*] Resolving ASVspoof 2019 LA dataset paths via kagglehub...")
        data_root = download_asvspoof2019()

    paths = get_la_paths(data_root)
    print(f"\n[*] LA Base Directory: {paths['la_root']}")
    
    report = check_dataset_integrity(paths)

    print("\n" + "-" * 65)
    print("  PARTITION BREAKDOWN")
    print("-" * 65)
    for part, stats in report["partitions"].items():
        print(f"  [{part.upper()}]")
        print(f"    Protocol Entries   : {stats['total_entries']:>8,}")
        print(f"    Bona Fide Samples  : {stats['bonafide']:>8,}")
        print(f"    Spoof Samples      : {stats['spoof']:>8,}")
        print(f"    Unique Speakers    : {stats['unique_speakers']:>8,}")
        print(f"    Unique Audio IDs   : {stats['unique_audios']:>8,}")
        print(f"    Missing Audio Files: {stats['missing_audio_files']:>8,}")

    print("\n" + "-" * 65)
    print("  CROSS-PARTITION LEAKAGE & OVERLAP CHECK")
    print("-" * 65)
    all_clean = True
    for pair, overlap in report["speaker_overlap"].items():
        print(f"  Speaker Overlap ({pair}): {overlap} speakers")
    for pair, overlap in report["audio_overlap"].items():
        status = "[CLEAN]" if overlap == 0 else "[LEAK DETECTED]"
        if overlap != 0:
            all_clean = False
        print(f"  Audio ID Overlap ({pair}): {overlap} audios  {status}")

    print("\n" + "=" * 65)
    if all_clean:
        print("  >>> DATASET VERIFICATION PASSED — ZERO AUDIO LEAKAGE <<<")
    else:
        print("  >>> WARNING: AUDIO LEAKAGE OR INTEGRITY ISSUES DETECTED <<<")
    print("=" * 65 + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ASVspoof 2019 LA Dataset Verification")
    parser.add_argument("--data_root", type=str, default=None, help="Root path of dataset")
    args = parser.parse_args()
    verify_dataset(args.data_root)

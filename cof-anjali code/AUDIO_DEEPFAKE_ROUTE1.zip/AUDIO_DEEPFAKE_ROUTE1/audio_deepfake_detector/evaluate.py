import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, confusion_matrix


def compute_eer(labels, scores):
    labels = np.asarray(labels)
    scores = np.asarray(scores)
    fpr, tpr, thresholds = roc_curve(labels, scores, pos_label=1)
    fnr = 1.0 - tpr
    diff = fpr - fnr

    exact = np.where(np.isclose(diff, 0.0))[0]
    if len(exact):
        i = int(exact[0])
        return float(fpr[i]), float(thresholds[i])

    crossing = np.where(diff[:-1] * diff[1:] < 0)[0]
    if len(crossing):
        i = int(crossing[0])
        d0, d1 = diff[i], diff[i + 1]
        alpha = -d0 / (d1 - d0)
        eer = fpr[i] + alpha * (fpr[i + 1] - fpr[i])
        threshold = thresholds[i] + alpha * (thresholds[i + 1] - thresholds[i])
        return float(eer), float(threshold)

    i = int(np.argmin(np.abs(diff)))
    return float((fpr[i] + fnr[i]) / 2.0), float(thresholds[i])


def compute_all_metrics(labels, scores, threshold=0.5):
    labels = np.asarray(labels)
    scores = np.asarray(scores)
    preds = (scores >= threshold).astype(int)

    acc = accuracy_score(labels, preds)
    prec = precision_score(labels, preds, zero_division=0)
    rec = recall_score(labels, preds, zero_division=0)
    f1 = f1_score(labels, preds, zero_division=0)
    try:
        auc = roc_auc_score(labels, scores)
    except ValueError:
        auc = float('nan')

    eer, eer_threshold = compute_eer(labels, scores)
    cm = confusion_matrix(labels, preds, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    pfa = fp / (fp + tn) if (fp + tn) else float('nan')
    pmiss = fn / (tp + fn) if (tp + fn) else float('nan')

    return {
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1': float(f1),
        'roc_auc': float(auc),
        'eer': float(eer),
        'eer_threshold': float(eer_threshold),
        'pfa': float(pfa),
        'pmiss': float(pmiss),
        'tp': int(tp), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn)
    }


def compute_per_attack_metrics(labels, scores, attack_ids, threshold=0.5):
    labels = np.asarray(labels)
    scores = np.asarray(scores)
    attack_ids = np.asarray(attack_ids)
    results = {}
    bona_mask = attack_ids == '-'

    for attack in sorted(set(attack_ids) - {'-'}):
        mask = (attack_ids == attack) | bona_mask
        if mask.sum() < 2:
            continue
        results[attack] = {
            'eer': float(compute_eer(labels[mask], scores[mask])[0]),
            'accuracy': float(accuracy_score(labels[mask], (scores[mask] >= threshold).astype(int))),
            'n_samples': int(mask.sum())
        }
    return results


def format_metrics_table(m, title='Evaluation Results'):
    return '\n'.join([
        '=' * 60,
        f'  {title}',
        '=' * 60,
        f"  Accuracy  : {m['accuracy']*100:7.2f}%",
        f"  Precision : {m['precision']*100:7.2f}%",
        f"  Recall    : {m['recall']*100:7.2f}%",
        f"  F1 Score  : {m['f1']*100:7.2f}%",
        f"  ROC-AUC   : {m['roc_auc']*100:7.2f}%",
        f"  EER       : {m['eer']*100:7.2f}%  (tau*={m['eer_threshold']:.4f})",
        '-' * 60,
        f"  P_fa      : {m['pfa']*100:7.2f}%",
        f"  P_miss    : {m['pmiss']*100:7.2f}%",
        '-' * 60,
        f"  TP={m['tp']:6d}  FP={m['fp']:6d}",
        f"  FN={m['fn']:6d}  TN={m['tn']:6d}",
        '=' * 60,
    ])


def format_per_attack_table(per_attack_dict, title='Per-Attack Breakdown'):
    lines = [
        '=' * 50,
        f'  {title}',
        '=' * 50,
        f"  {'Attack':<10} {'EER (%)':>10} {'Acc (%)':>10} {'N':>8}",
        '-' * 50,
    ]
    for attack in sorted(per_attack_dict):
        r = per_attack_dict[attack]
        lines.append(f"  {attack:<10} {r['eer']*100:>10.2f} {r['accuracy']*100:>10.2f} {r['n_samples']:>8}")
    lines.append('=' * 50)
    return '\n'.join(lines)
